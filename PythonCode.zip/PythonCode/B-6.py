from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route('/')
def hello():
    return 'Hello Flask!'

@app.route('/new', methods=['POST'])
def name():
    return 'Mary!'

# -- ↓ 路由：註冊節點 ↓ -- #
@app.route('/nodes/register', methods=['POST'])
def register_nodes():
    values = request.get_json() # 接收資料, values 為字典型別
    nodes = values['nodes'] # 取出字典中鍵為 'nodes' 的資料
    if nodes is None:   # 如果找不到資料, 則代表用戶端傳遞資料的格式錯誤
        return '請輸入正確的節點位址', 400
    return jsonify(values)  # 回傳非字串資料

if __name__ == '__main__':
    app.run()
    