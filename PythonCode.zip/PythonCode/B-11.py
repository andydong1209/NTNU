from time import time
import json
from hashlib import sha256
from uuid import uuid4
from flask import Flask, request, jsonify
import requests

class Blockchain(object):
    def __init__(self):
        self.current_transactions = []                  # 儲存當前交易
        self.chain = []                                 # 儲存區塊鏈
        self.nodes = set()                              # 用 set 儲存節點 (不重複元素)
        self.new_block(previous_hash=1, nonce=100)      # 創建創世(genesis)區塊
        
    # -- ↓ 創建新區塊 ↓ -- #
    def new_block(self, nonce, previous_hash=None):    
        block = {'index': len(self.chain) + 1,                  # 索引為總鏈長 
                 'timestamp': time(),                           # 區塊產生時間
                 'transactions': self.current_transactions,     # 交易清單
                 'nonce': nonce,                                # 工作量證明 (挖礦)
                 'previous_hash': previous_hash or self.hash(self.chain[-1])   # 前一個區塊的 Hash 值
        }
        self.current_transactions = []  # 重置當前交易清單
        self.chain.append(block)        # 將新區塊加入鏈中
        return block                    # 回傳新區塊
    
    # -- ↓ 計算區塊雜湊值的方法 ↓ -- #
    @staticmethod
    def hash(block):
        block_string = json.dumps(block, sort_keys=True).encode('utf-8')   # 將 block (字典) 轉成 json 字串
        return sha256(block_string).hexdigest() 

    # -- ↓ 交易方法 ↓ -- #
    def new_transaction(self, sender, recipient, amount):
        # -- ↓ 建立交易 ↓ -- #
        trans = {'sender': sender,
                 'recipient': recipient,
                 'amount': amount}
        self.current_transactions.append(trans)     # 將交易加入當前交易紀錄清單中
        # -- ↓ 回傳將被新增到的區塊 (下一個待挖掘的區塊) 的索引 ↓ -- #
        return self.last_block['index'] + 1
    
    @property
    def last_block(self):
        # Returns the last Block in the chain
        return self.chain[-1]    # 回傳鏈的最後一個區塊

    # -- ↓ 挖礦演算法：工作量的證明 ↓ -- #
    def find_nonce(self, last_nonce):

        nonce = 0
        while self.valid_nonce(last_nonce, nonce) is False:
            nonce += 1
        return nonce
    
    @staticmethod
    def valid_nonce(last_nonce, nonce):
        guess = f'{last_nonce}{nonce}'.encode()
        guess_hash = sha256(guess).hexdigest()
        return guess_hash[:4] == '0000'
    
    # -- ↓ 加入其他節點位址的 Method  ↓ -- #
    def add_node(self, address): 
        self.nodes.add(address)   # 將其他節點的位址加入到區塊鏈 node 清單中
    
    # -- ↓ 共識演算法：找尋網路中的最長鏈 ↓ -- #
    def resolve_conflicts(self): 
        neighbours = self.nodes         # 所有的節點
        new_chain = None                # 用來記錄是否有找到新鏈
        max_length = len(self.chain)    # 紀錄自己的鏈的長度
        my_last_bk_t = blockchain.last_block['timestamp']   # 紀錄自己最後一個區塊的 timestamp
        # -- ↓ 歷遍所有其他的節點、下載他們的鏈 ↓ -- #
        for node in neighbours:
            response = requests.get(f'{node}/chain') # 對其他節點發出查看鏈的請求
            if response.status_code == 200:    
                chain = response.json()['chain']        # 取得別人的鏈
                length = response.json()['length']      # 取得別人的鏈長
                last_bk_t = response.json()['last_bk_t']    # 取得別人鏈中最後一個區塊的時間戳
                # -- ↓ 1. 為合法的鏈 ↓ -- #
                if self.valid_chain(chain):
                    # -- ↓ 2. 滿足 A:你的鏈長比我長 或 B:鏈長相等, 但你最後一個區塊比我還早產出 ↓ -- #
                    if (length > max_length) or (length == max_length and last_bk_t < my_last_bk_t):
                        max_length = length     # 紀錄新長度
                        new_chain = chain       # 紀錄新鏈
        # -- ↓ 若有找到新的合法長鏈 ↓ -- #    
        if new_chain:
            self.chain = new_chain      # 將自己的鏈替換成新鏈
            return True
        # -- ↓ 沒有找到新合法長鏈 ↓ -- #    
        return False
 
    # -- ↓ 驗證是否為合法的鏈 ↓ -- #
    def valid_chain(self, chain):
        last_block = chain[0]   # 前一個區塊
        current_index = 1
        while current_index < len(chain):
            block = chain[current_index]
            print(f'{last_block}')
            print(f'{block}')
            print("\n-----------\n")
            # -- ↓ 確認區塊的雜湊值是否正確 ↓ -- #
            if block['previous_hash'] != self.hash(last_block): 
                return False
            # -- ↓ 確認區塊的 nonce 是否正確 ↓ -- #
            if not self.valid_nonce(last_block['nonce'], block['nonce']):
                return False
            # -- ↓ 此區塊驗證成功, 換下一個區塊進行驗證 ↓ -- #
            last_block = block 
            current_index += 1
        return True  # 執行到這裡代表每個區塊皆驗證成功 

#---- ↓ 運作區塊鏈 ↓ ----#
app = Flask(__name__)   # 產生一個 Flask 物件
node_uuid = str(uuid4()).replace('-', '')   # 為此節點產生一個 UUID
blockchain = Blockchain()   # 產生 Blockchain 物件
print('此節點的 UUID:', node_uuid)
print('當前交易:', blockchain.current_transactions)
print('區塊鏈:', blockchain.chain)
print('區塊鏈網路用戶:', blockchain.nodes)
print('區塊鏈最後一個區塊索引位置:', blockchain.last_block['index'])

# -- ↓ 路由：挖礦 ↓ -- #
@app.route('/mine', methods=['GET'])
#---- ↓ 挖礦自訂函式 ↓  ----#
def mine():
    last_nonce = blockchain.last_block['nonce']
    new_nonce = blockchain.find_nonce(last_nonce)
    print('產生新區塊的 nonce:', new_nonce)   # 算出新區塊的 nonce 程式才會繼續往下執行
    # -- ↓ 給予獎勵:發起一筆給自己的交易 ↓ -- #
    blockchain.new_transaction(sender='0',  # 匯款人為 0 代表是新挖出來的幣
                               recipient=node_uuid, # 收款人為節點 (自己) 的 UUID
                               amount=1,    # 一個幣
    )
    # -- ↓ 產生新區塊 ↓ -- #
    newBlock = blockchain.new_block(new_nonce)  # 執行產生新區塊的 Method
    response = {
        'message': "New Block Forged",
        'index': newBlock['index'],
        'transactions': newBlock['transactions'],
        'nonce': newBlock['nonce'],
        'previous_hash': newBlock['previous_hash'],
        }
    return jsonify(response), 200 
    
# -- ↓ 路由：查看區塊鏈中的區塊資訊 ↓ -- #
@app.route('/chain', methods=['GET'])
def check_chain():
    response = {
        'chain': blockchain.chain,
        'length': len(blockchain.chain),
        'last_bk_t':blockchain.last_block['timestamp'],   # 取得鏈的最後一個 block 的 timestamp
    }
    return jsonify(response), 200

# -- ↓ 路由：加入其他節點位址 ↓ -- #
@app.route('/nodes/register', methods=['POST'])
def register_nodes():
    values = request.get_json() # 接收資料, values 為字典型別
    nodes = values['nodes'] # 取出字典中鍵為 'nodes' 的資料 (串列)
    if nodes is None:   # 如果找不到資料, 則代表用戶端傳遞資料的格式錯誤
        return '請輸入正確的節點位址', 400    
    # -- ↓ 提供節點正確, 將所有提供的節點註冊到區塊鏈的節點清單中 ↓ -- #
    for node in nodes:
        blockchain.add_node(node)
    response = {
            'message': '新節點位址已被加入',
            'total_nodes': list(blockchain.nodes),
            }
    return jsonify(response)  # 回傳非字串資料


# -- ↓ 路由：執行共識演算法 ↓ -- #
@app.route('/nodes/resolve', methods=['GET'])
def consensus():
    replaced = blockchain.resolve_conflicts()
    if replaced:    # 我們節點的鏈被替換成其他節點的長鏈了
        response = {
                'message': '我的鏈被取代了',
                'new_chain': blockchain.chain
                }
    else:           # 我們節點的鏈為最長鏈, 故沒被替換
        response = {    
                'message': '我的鏈是最長合法鏈, 沒被取代',
                'chain': blockchain.chain
                }

    return jsonify(response), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)  # 以 http://127.0.0.1:5002/ 啟動網站
