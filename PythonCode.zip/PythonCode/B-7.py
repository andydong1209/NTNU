from time import time
import json
from hashlib import sha256
from uuid import uuid4
from flask import Flask, request, jsonify


class Blockchain(object):
    def __init__(self):
        self.current_transactions = []                  # 儲存當前交易
        self.chain = []                                 # 儲存區塊鏈
        self.nodes = set()                              # 用 set 儲存節點 (不重複元素)
        self.new_block(previous_hash=1, nonce=100)      # 創建創世(genesis)區塊
        
    # -- ↓ 創建新區塊 ↓ -- #
    def new_block(self, nonce, previous_hash=None):    
        block = {'index': len(self.chain) + 1,                  # 索引為總鏈長 
                 'timestamp': time(),                           # 區塊產生時間
                 'transactions': self.current_transactions,     # 交易清單
                 'nonce': nonce,                                # 工作量證明 (挖礦)
                 'previous_hash': previous_hash or self.hash(self.chain[-1])   # 前一個區塊的 Hash 值
        }
        self.current_transactions = []  # 重置當前交易清單
        self.chain.append(block)        # 將新區塊加入鏈中
        return block                    # 回傳新區塊
    
    # -- ↓ 計算區塊雜湊值的方法 ↓ -- #
    @staticmethod
    def hash(block):
        block_string = json.dumps(block, sort_keys=True).encode('utf-8')   # 將 block (字典) 轉成 json 字串
        return sha256(block_string).hexdigest() 

    # -- ↓ 交易方法 ↓ -- #
    def new_transaction(self, sender, recipient, amount):
        # -- ↓ 建立交易 ↓ -- #
        trans = {'sender': sender,
                 'recipient': recipient,
                 'amount': amount}
        self.current_transactions.append(trans)     # 將交易加入當前交易紀錄清單中
        # -- ↓ 回傳將被新增到的區塊 (下一個待挖掘的區塊) 的索引 ↓ -- #
        return self.last_block['index'] + 1
    
    @property
    def last_block(self):
        # Returns the last Block in the chain
        return self.chain[-1]    # 回傳鏈的最後一個區塊

    # -- ↓ 挖礦演算法：工作量的證明 ↓ -- #
    def find_nonce(self, last_nonce):

        nonce = 0
        while self.valid_nonce(last_nonce, nonce) is False:
            nonce += 1
        return nonce
    
    @staticmethod
    def valid_nonce(last_nonce, nonce):
        guess = f'{last_nonce}{nonce}'.encode()
        guess_hash = sha256(guess).hexdigest()
        return guess_hash[:4] == '0000'

#---- ↓ 運作區塊鏈 ↓ ----#
app = Flask(__name__)   # 產生一個 Flask 物件
node_uuid = str(uuid4()).replace('-', '')   # 為此節點產生一個 UUID
blockchain = Blockchain()   # 產生 Blockchain 物件
print('此節點的 UUID:', node_uuid)
print('當前交易:', blockchain.current_transactions)
print('區塊鏈:', blockchain.chain)
print('區塊鏈網路用戶:', blockchain.nodes)
print('區塊鏈最後一個區塊索引位置:', blockchain.last_block['index'])

# -- ↓ 路由：挖礦 ↓ -- #
@app.route('/mine', methods=['GET'])
#---- ↓ 挖礦自訂函式 ↓  ----#
def mine():
    last_nonce = blockchain.last_block['nonce']
    new_nonce = blockchain.find_nonce(last_nonce)
    print('產生新區塊的 nonce:', new_nonce)   # 算出新區塊的 nonce 程式才會繼續往下執行
    # -- ↓ 給予獎勵:發起一筆給自己的交易 ↓ -- #
    blockchain.new_transaction(sender='0',  # 匯款人為 0 代表是新挖出來的幣
                               recipient=node_uuid, # 收款人為節點 (自己) 的 UUID
                               amount=1,    # 一個幣
    )
    # -- ↓ 產生新區塊 ↓ -- #
    newBlock = blockchain.new_block(new_nonce)  # 執行產生新區塊的 Method
    response = {
        'message': "New Block Forged",
        'index': newBlock['index'],
        'transactions': newBlock['transactions'],
        'nonce': newBlock['nonce'],
        'previous_hash': newBlock['previous_hash'],
        }
    return jsonify(response), 200 
    
if __name__ == '__main__':
    app.run()   # 啟動網站
